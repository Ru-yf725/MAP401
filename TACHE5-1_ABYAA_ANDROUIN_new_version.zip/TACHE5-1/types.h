typedef struct Vecteur_
{ 
  double x,y; // coordonnées
} Vecteur;

typedef struct Point_
{
  double x,y; // coordonnées
} Point;